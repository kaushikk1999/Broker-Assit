# Phase 3 Scope

Phase 3 includes:
- FastAPI backend foundation
- Authentication and access control
- Widget origin authentication
- Domain allowlist enforcement
- Anonymous session tokens
- Admin authentication
- Rate limiting, abuse protection, and quotas
- Chat API foundation
- Search API foundation
- Filings API foundation
- Stock information API foundation
- PostgreSQL schema and persistence layer
- Redis cache and rate-limit layer
- Qdrant startup validation and collection contract

Phase 3 does not include:
- Data ingestion pipeline implementation
- Embedding pipeline implementation
- RAG retrieval implementation
- Frontend implementation
- Model hosting implementation
- Production launch work beyond backend foundation
