# Business Inputs Required

Claude Code needs the following before implementation:
- Final pilot tenant(s)
- Tenant hierarchy and ownership model
- Supported user personas
- Supported surfaces: widget, admin, internal API
- Supported languages for Phase 3 behavior
- Non-goals for this phase
- Success definition for backend foundation
- Performance target
- Availability/SLA target
- Data retention policy
- Privacy/compliance constraints
- Any brand-specific onboarding/offboarding rules
