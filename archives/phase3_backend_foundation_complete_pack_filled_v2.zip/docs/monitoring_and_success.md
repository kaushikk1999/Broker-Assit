# Monitoring Requirements and Success Criteria

Monitoring requirements:
- Health checks
- Readiness checks
- Liveness checks
- Structured logging
- Correlation/request IDs
- Sentry or equivalent error tracking
- OpenTelemetry traces
- Metrics for latency, errors, rate limits, quotas, blocks, and auth failures
- Alerting on dependency failures

Success criteria:
- Widget sessions can be created safely
- Domain allowlist enforcement works
- Anonymous sessions are attributable to tenant and session
- Rate limits and quotas block abuse before expensive downstream calls
- Admin authentication works and is audited
- PostgreSQL persistence is consistent
- Redis behavior is predictable
- Qdrant startup validation succeeds
- No cross-tenant leakage is possible
- API contracts are stable and documented
