# Provided Integration Details

## Qdrant
- Qdrant Cluster Endpoint:
  https://d8611363-9c4b-4d62-88ad-84be4dfcfb14.eu-central-1-0.aws.cloud.qdrant.io

- Qdrant API key:
  eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2Nlc3MiOiJtIiwic3ViamVjdCI6ImFwaS1rZXk6YTE5NDQ5MzEtMTIzYS00MDg2LWE3MTItODRiODY1OGRjOGY5In0.Y5-Q2mZUWpMcQmRfG0U8dd566kCLDy20XXWFyvtpipA

## Ollama
- Ollama API key:
  2c485fdd41484a8fb22f4f0504b9aefc.DX7r8mo3VHaDojaXXcqRyM15

## Notes
- These values are included exactly as provided by the project owner.
- They should be treated as sensitive credentials.
- Do not log them or print them in application output.
