# Redis and Qdrant Requirements

Redis decisions needed:
- Session cache structure
- Chat context storage format
- Rate limit key design
- TTL policies
- Atomic increment strategy
- Failure behavior if Redis is unavailable
- Namespacing rules
- Serialization format

Qdrant decisions needed:
- Collection naming convention
- Whether Phase 3 creates or only validates collections
- Dense vector dimension source
- Sparse vector configuration
- Payload fields allowed
- Foreign key strategy for document_id and chunk_id
- Metadata filters supported at retrieval time later
- Tenant isolation strategy
- Startup validation behavior
- Reindex/update semantics
- Backup/snapshot expectations
