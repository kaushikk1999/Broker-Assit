# Constraints and Assumptions To Avoid

Constraints:
- No model weights inside FastAPI or Railway application services
- No Phase 4 ingestion implementation
- No Phase 5 embedding implementation
- No Phase 6 retrieval implementation
- No hardcoded embedding dimensions
- No citations from Qdrant payload
- No unaudited anonymous chat traffic
- No expensive AI calls before security checks pass

Assumptions to avoid:
- Assuming tenant model without approval
- Assuming admin auth method
- Assuming JWT expiration policy
- Assuming Redis can act as durable storage
- Assuming Qdrant payload may contain citation fields
- Assuming rate limits are standard/default
- Assuming domain wildcard behavior
- Assuming search/chat contracts can be inferred later
