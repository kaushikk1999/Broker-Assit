# API Contracts Required

Phase 3 should define contracts for:
- Widget bootstrap/session endpoint
- Chat endpoint
- Search endpoint
- Filings endpoint
- Stock information endpoint
- Admin authentication endpoint
- Admin dashboard endpoints
- API key management endpoints
- Allowlist management endpoints
- Quota management endpoints
- Health/readiness endpoints

Each endpoint needs:
- Request schema
- Response schema
- Authentication requirements
- Error codes
- Pagination/filtering rules if applicable
- Rate-limit and quota headers if applicable
- Idempotency behavior if applicable
