# PostgreSQL Requirements

Claude Code needs exact decisions for:
- users table
- sessions table
- api_keys table
- domain_allowlist table
- usage_quotas table
- feedback table
- analytics table
- documents table
- document_versions table
- document_audit_history table
- chat_conversations table
- chat_messages table
- abuse_events / blocked_requests table
- admin_audit_log table

Required decisions per table:
- Primary key type
- Foreign keys and relationships
- Required vs optional fields
- Unique constraints
- Check constraints / enums
- Soft delete vs hard delete
- Indexing strategy
- Retention policy
- Audit policy
- Data privacy handling
