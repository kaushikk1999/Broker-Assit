# Authentication & Security Decisions Required

Claude Code needs exact decisions for:
- Widget authentication model
- Widget API key format and rotation
- Domain allowlist matching rules
- Origin vs Referer precedence
- Anonymous session token format and lifetime
- Session binding rules
- Admin authentication method
- MFA requirement
- Admin role model
- Password policy if passwords are used
- API key storage and hashing
- API key revocation behavior
- Rate limit dimensions and thresholds
- Quota enforcement rules
- Abuse prevention and CAPTCHA/challenge policy
- Block duration and escalation policy
- CORS policy
- Secret management rules
- Logging redaction rules
- Audit trail requirements
