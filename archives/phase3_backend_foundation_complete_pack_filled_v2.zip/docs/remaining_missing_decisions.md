# Phase 3 Remaining Missing Decisions

## 1. Business / Product Decisions
- Final pilot tenant(s)
- Tenant hierarchy model
- Supported personas
- Supported surfaces in Phase 3
- Phase 3 non-goals
- Success definition for Phase 3
- Performance target
- Availability/SLA target
- Data retention policy
- Privacy/compliance constraints
- Brand-specific onboarding/offboarding rules

## 2. Backend Architecture Decisions
- Monolith vs modular FastAPI
- API versioning strategy
- Service layer pattern
- Repository/data-access pattern
- Dependency injection approach
- Middleware order
- Startup validation behavior
- Error handling strategy
- Logging and correlation ID strategy
- Idempotency strategy
- Transaction strategy
- Pagination/filtering conventions
- Timezone standard
- Serialization standards

## 3. PostgreSQL Schema Decisions
- Primary key type for all tables
- Foreign key relationships
- Required vs optional fields
- Unique constraints
- Check constraints / enums
- Soft delete vs hard delete
- Indexing strategy
- Retention policy
- Audit policy
- Data privacy handling
- Specific tables: users, sessions, api_keys, domain_allowlist, usage_quotas, feedback, analytics, documents, document_versions, document_audit_history, chat_conversations, chat_messages, abuse_events / blocked_requests, admin_audit_log

## 4. Authentication & Security Decisions
- Widget authentication model
- Widget API key format and rotation
- Domain allowlist matching rules
- Origin vs Referer precedence
- Anonymous session token format and lifetime
- Session binding rules
- Admin authentication method
- MFA requirement
- Admin role model
- Password policy if passwords are used
- API key storage and hashing
- API key revocation behavior
- Rate limit dimensions and thresholds
- Quota enforcement rules
- Abuse prevention and CAPTCHA/challenge policy
- Block duration and escalation policy
- CORS policy
- Secret management rules
- Logging redaction rules
- Audit trail requirements

## 5. Redis Decisions
- Session cache structure
- Chat context storage format
- Rate limit key design
- TTL policies
- Atomic increment strategy
- Failure behavior if Redis is unavailable
- Namespacing rules
- Serialization format

## 6. Qdrant Decisions
- Collection naming convention
- Whether Phase 3 creates or only validates collections
- Dense vector dimension source
- Sparse vector configuration
- Payload fields allowed
- Foreign key strategy for document_id and chunk_id
- Metadata filters supported at retrieval time later
- Tenant isolation strategy
- Startup validation behavior
- Reindex/update semantics
- Backup/snapshot expectations

## 7. API Contract Decisions
- Exact request schemas
- Exact response schemas
- Error code taxonomy
- Authentication per endpoint
- Pagination rules
- Filtering/sorting rules
- Rate-limit headers
- Quota headers
- Idempotency behavior
- Citation response format
- Endpoint contracts for widget bootstrap/session, chat, search, filings, stock information, admin authentication, admin dashboard, API key management, allowlist management, quota management, health/readiness

## 8. Monitoring / Operations Decisions
- Health check criteria
- Readiness criteria
- Liveness criteria
- Structured logging format
- Correlation/request ID propagation
- Sentry scope
- OpenTelemetry scope
- Metrics definitions
- Alert thresholds
- Dependency failure handling

## 9. Constraints / Assumptions Still Unresolved
- Exact embedding dimension handling confirmation
- Whether search/chat APIs are stubbed or fully functional in Phase 3
- Whether future Phase 4 contracts need placeholders now
- Whether tenant and admin seed data must be created in Phase 3
- Whether local/dev environments use mock external providers
- Whether audit logging is mandatory for all admin writes
