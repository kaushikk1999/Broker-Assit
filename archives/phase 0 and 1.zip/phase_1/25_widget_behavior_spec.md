# Phase 1 — Widget Behavior Spec

## Floating widget
- TBD

## Full-screen assistant
- TBD

## Mobile behavior
- TBD

## Escalation behavior
- TBD
