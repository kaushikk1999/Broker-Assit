# Phase 1 — Visual Reference Board

## Style direction
- TBD

## Inspirations
- TBD

## Anti-inspirations
- TBD
