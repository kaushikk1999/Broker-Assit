# Phase 0 — Research Permissions Matrix

| Research Item | Allowed | Notes |
|---|---|---|
| Public website research | TBD | TBD |
| Login-based research | TBD | TBD |
| Screenshot capture | TBD | TBD |
| Pricing page review | TBD | TBD |
| Account-opening flow review | TBD | TBD |
| Paid tools / licensed tools | TBD | TBD |
| Internal documentation access | TBD | TBD |
| Mobile browser testing | TBD | TBD |
