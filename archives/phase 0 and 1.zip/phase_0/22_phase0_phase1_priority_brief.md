# Phase 0 → Phase 1 Priority Brief

## Inputs to Phase 1
- TBD

## Priority pages
- TBD

## Priority journeys
- TBD

## Priority CTAs
- TBD

## Multilingual implications
- TBD

## Open questions
- TBD
