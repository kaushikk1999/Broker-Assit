# Rollout Checklist

## Before implementation
- Confirm roadmap scope
- Confirm source tree
- Confirm open ADRs
- Confirm vendor credentials availability
- Confirm staging environment

## Before merge
- All tests passing
- No regression in mocks-first mode
- Docs updated
- Phase status updated
- No secret leakage in logs or tests

## Before deployment
- Validate env vars in staging
- Validate real adapter latency and failure handling
- Validate fallback behavior
- Validate security gate ordering
- Validate API stability
