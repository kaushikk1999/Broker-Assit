# Risks and Open Questions

## Risks
- Source-tree visibility may differ from docs
- Open ADRs may block production wiring
- Vendor API differences may require adapter-specific shims
- Misaligned roadmap naming could cause scope confusion
- Secrets handling may not yet be production ready

## Open questions to resolve before coding
1. Confirm whether Phase 4 is vendor adapters or ingestion in the authoritative roadmap.
2. Confirm approved vendor list for translation, LLM, reranker, Qdrant, and market data.
3. Confirm secret storage pattern on Railway.
4. Confirm rollout order and fallback policy.
5. Confirm whether any schema changes are required.
