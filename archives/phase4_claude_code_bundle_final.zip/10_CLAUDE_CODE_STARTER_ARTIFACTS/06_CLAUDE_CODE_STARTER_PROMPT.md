# Claude Code Starter Prompt

You are continuing BrokerAssist.

Your task is to complete Phase 4 only.

## Non-negotiable constraints
- Do not implement Phase 5 or later.
- Do not implement ingestion workers unless the current repo truth clearly proves they are part of Phase 4.
- Do not break mocks-first mode.
- Do not move citation authority away from PostgreSQL.
- Do not route market data through Qdrant.
- Do not remove existing auth/rate-limit safeguards.

## Required approach
1. Inspect the repository tree.
2. Verify current adapter interfaces, services, and tests.
3. Identify reusable code.
4. Identify missing real vendor adapter work.
5. Implement only Phase 4 requirements.
6. Add tests for every changed path.
7. Update docs and phase status.

## Deliverables expected
- Real vendor adapters
- Configurable factory selection
- Updated tests
- Updated docs
- No unrelated refactors

## Important output expectation
Before coding, produce a concise but exact mapping of:
- existing files to reuse
- files to modify
- files to create
- tests to add
- risks and open decisions
