#!/usr/bin/env bash
echo "Migrate script placeholder"
