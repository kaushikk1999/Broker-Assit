# BrokerAssist — Phase 4 Claude Code Bundle

This bundle is designed to help Claude Code complete **Phase 4** safely and accurately.

## Purpose
- Provide authoritative planning context
- Provide source tree discovery guidance
- Preserve scope boundaries
- Prevent drift into later phases
- Enable implementation planning for the current repository state

## Important scope note
The attached project docs currently describe Phase 4 as **Real Vendor Adapters**.
If the authoritative roadmap differs, Claude Code must follow the roadmap included in this bundle.

## How Claude Code should use this bundle
1. Read the roadmap and phase-status docs first.
2. Inspect the repo manifest and tree next.
3. Review backend, frontend, config, DB, tests, and ADR docs.
4. Confirm what already exists and what is missing.
5. Implement only Phase 4 items.
6. Do not begin Phase 5 or later.

## What is included
- Roadmap and phase-definition docs
- Backend source tree placeholder structure
- Frontend source tree placeholder structure
- Configuration/deployment placeholders
- DB/migration placeholders
- Test placeholders
- Architecture/reference docs
- Discovery/ADR placeholders
- Repo manifest and file-tree index
- Starter prompt and rollout guidance

## What is not included
- Real codebase files from the source repository
- Credentials or secrets
- Any production-only secret values

## Source-of-truth priority
1. ROADMAP.md
2. PHASE_STATUS.md
3. DECISIONS_AND_OPEN_ITEMS.md
4. architecture/reference docs
5. code
6. tests
7. notes and examples
