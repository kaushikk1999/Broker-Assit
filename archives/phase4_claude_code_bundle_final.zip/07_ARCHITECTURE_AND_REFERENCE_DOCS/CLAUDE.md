# Placeholder for 07_ARCHITECTURE_AND_REFERENCE_DOCS/CLAUDE.md

Replace with the exact repository document.
