# BrokerAssist — Repo Manifest

This manifest is a navigation aid for Claude Code and maintainers.
It lists the major folders/files in the Phase 4 bundle, their purpose, and how they should be used.

> Important: This bundle is intended to support Phase 4 only.

## 1) Truth sources / planning docs
| Path | Purpose | Phase 4 Relevance | Authoritative | Action |
|---|---|---:|---:|---|
| `01_ROADMAP_AND_PHASE_DOCS/ROADMAP.md` | Phase roadmap | Critical | Yes | Read |
| `01_ROADMAP_AND_PHASE_DOCS/PHASE_STATUS.md` | Current phase status | Critical | Yes | Read |
| `01_ROADMAP_AND_PHASE_DOCS/NEXT_PHASE_PLAN.md` | Next-phase execution plan | High | Yes | Read |
| `01_ROADMAP_AND_PHASE_DOCS/DECISIONS_AND_OPEN_ITEMS.md` | Decisions + open blockers | Critical | Yes | Read |
| `01_ROADMAP_AND_PHASE_DOCS/CLAUDE.md` | Agent guidance | High | Yes | Read |
| `01_ROADMAP_AND_PHASE_DOCS/PROJECT_JOURNEY.md` | Project history and phase context | Medium | Yes | Read |

## 2) Backend / frontend / config / DB / tests / docs / discovery / vendor contracts
This bundle should contain the complete repository snapshot in the following top-level groups:
- `02_SOURCE_TREE_BACKEND/`
- `03_SOURCE_TREE_FRONTEND/`
- `04_CONFIG_AND_DEPLOYMENT/`
- `05_DB_AND_MIGRATIONS/`
- `06_TESTS/`
- `07_ARCHITECTURE_AND_REFERENCE_DOCS/`
- `08_DISCOVERY_AND_ADR_NOTES/`
- `09_VENDOR_AND_INTEGRATION_CONTRACTS/`

## 3) Usage rules
1. Read planning docs first.
2. Inspect backend source second.
3. Inspect tests before coding.
4. Preserve mocks-first mode.
5. Do not implement later phases.
6. Do not move citation authority away from PostgreSQL.
7. Do not route market data through vector retrieval.
8. Update docs/status when Phase 4 work is completed.
