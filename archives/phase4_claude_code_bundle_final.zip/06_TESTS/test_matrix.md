# Phase 4 Test Matrix

## Unit tests
- Adapter factory returns mock backend when BA_USE_MOCKS=true
- Adapter factory returns real backend when enabled
- Provider-specific error mapping
- Timeout/retry handling
- Input/output contract validation

## Integration tests
- Real adapter path with mocked HTTP responses
- Mock-first flow remains deterministic
- Security gate still blocks before vendor calls
- Routing still separates market vs knowledge

## End-to-end tests
- Widget request through current API with mock providers
- Widget request through current API with one real provider enabled
- Fallback behavior when provider fails

## Regression tests
- Citations still resolve from PostgreSQL
- Market requests never touch retrieval/vector paths
- Existing API payloads remain stable
- Admin/auth behavior remains unchanged
