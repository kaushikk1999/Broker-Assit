# Next Phase Plan

See the project docs in the repository snapshot.