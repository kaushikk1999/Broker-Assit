# Data Model

See the project docs in the repository snapshot.