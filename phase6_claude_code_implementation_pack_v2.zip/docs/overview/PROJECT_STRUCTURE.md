# Project Structure

See the project docs in the repository snapshot.