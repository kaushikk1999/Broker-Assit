# Architecture

See the project docs in the repository snapshot.