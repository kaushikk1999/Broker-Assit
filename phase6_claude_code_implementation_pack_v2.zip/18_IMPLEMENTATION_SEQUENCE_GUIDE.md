# Implementation Sequence Guide

Use the sequence in `14_IMPLEMENTATION_SEQUENCE.md` as the execution order.

Rule of thumb:
- validate before changing
- add tests before enabling behavior
- keep the mocks-first path intact
- do not implement Phase 7 concerns inside Phase 6
