# Readiness Gate Checklist

- [ ] Auth/rate-limit ordering verified
- [ ] Intent router verified
- [ ] Translation-before-retrieval verified
- [ ] Hybrid dense+sparse retrieval verified
- [ ] RRF verified
- [ ] Hosted reranker contract verified
- [ ] PostgreSQL citation lookup verified
- [ ] Mocks-first path still works
