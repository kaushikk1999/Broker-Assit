# Phase 6 Implementation Sequence

1. Verify auth and rate-limit ordering.
2. Verify intent router and routing fork.
3. Confirm language detection and translation contract.
4. Confirm embedding and Qdrant readiness.
5. Verify hybrid retrieval and metadata filter path.
6. Verify RRF fusion and top-20 candidate selection.
7. Verify hosted reranker contract and response format.
8. Verify PostgreSQL citation resolution path.
9. Confirm Ollama Cloud generation and response translation.
10. Add or update tests for each stage before implementation.
