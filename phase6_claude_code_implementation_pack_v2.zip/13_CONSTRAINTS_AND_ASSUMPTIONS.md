# Constraints and Assumptions

## Constraints
- No model weights inside FastAPI or Railway app processes
- No citations from vector payloads
- No market data from Qdrant
- No reranking of the full collection
- Metadata filters applied during retrieval

## Assumptions to avoid
- Assuming Phase 4 ingestion is complete
- Assuming Qdrant hybrid retrieval is already production-ready
- Assuming hosted reranker exists without verification
- Assuming citations can be derived from vector storage
