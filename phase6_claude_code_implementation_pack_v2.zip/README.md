# BrokerAssist Phase 6 Claude Code Implementation Pack v2

This archive is a stronger Phase 6 handoff pack for Claude Code.

## What this pack includes
- Phase 6 requirements and implementation guardrails
- Real file inventory template
- Code review prompts for Claude Code
- Module-by-module audit checklist
- Readiness gate checklist
- Phase 6 implementation sequence
- Claude Code first-pass instructions
- Source-aware docs index and handoff references

## How to use this pack
1. Read the architecture and Phase 6 requirements first.
2. Walk the file inventory against the repository.
3. Use the module audit checklist to verify code reality.
4. Use the code review prompts to inspect the current implementation.
5. Pass the readiness gates before writing any Phase 6 code.
6. Draft the implementation plan only after discovery is complete.

## Source basis
Synthesized from the roadmap and project documentation structure you provided.

## Important note
This archive is designed for planning and code discovery. It does not implement Phase 6.
