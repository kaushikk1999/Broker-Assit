# Phase 6 Requirements

## Canonical pipeline
User question -> auth/rate-limit -> language detection -> intent classification -> routing fork

### Branch A: Market data
- FastAPI Market Service
- Redis cache
- live API/WebSocket source
- translate response back to user language if required

### Branch B: Knowledge / RAG
- normalize / translate query to English
- query expansion
- embedding generation with embeddinggemma
- hybrid retrieval in Qdrant
- metadata filters at retrieval time
- reciprocal rank fusion (RRF)
- cross-encoder reranking on hosted endpoint
- top-5 chunk selection
- context assembly
- Gemma generation via Ollama Cloud
- translate answer back to user language
- citations resolved from PostgreSQL

## Non-negotiable rules
- No model weights inside the FastAPI process
- No citations from Qdrant payload
- No market data from Qdrant
- Never rerank the entire collection
- Apply metadata filters during retrieval, not after fusion
- Preserve document_id and chunk_id through the pipeline
