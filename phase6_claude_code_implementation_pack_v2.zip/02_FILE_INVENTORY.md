# Real File Inventory Template

Use this template while reviewing the repository.

| File / Folder | Exists | Purpose | Phase | Owner Module | Notes / Gaps |
|---|---:|---|---|---|---|
| `app/main.py` |  |  |  |  |  |
| `app/config.py` |  |  |  |  |  |
| `app/core/security.py` |  |  |  |  |  |
| `app/core/ratelimit.py` |  |  |  |  |  |
| `app/services/intent_router.py` |  |  |  |  |  |
| `app/services/rag_pipeline.py` |  |  |  |  |  |
| `app/services/embedding_pipeline.py` |  |  |  |  |  |
| `app/services/market_service.py` |  |  |  |  |  |
| `app/adapters/qdrant_real.py` |  |  |  |  |  |
| `app/adapters/ollama_cloud.py` |  |  |  |  |  |
| `app/adapters/mocks.py` |  |  |  |  |  |
| `app/db/models.py` |  |  |  |  |  |
| `app/db/seed.py` |  |  |  |  |  |
| `app/api/routes_chat.py` |  |  |  |  |  |
| `app/api/routes_admin.py` |  |  |  |  |  |
| `tests/test_phase5_qdrant.py` |  |  |  |  |  |
| `tests/test_phase5_pipeline.py` |  |  |  |  |  |
| `frontend/lib/api.js` |  |  |  |  |  |
| `frontend/lib/i18n.js` |  |  |  |  |  |

## Inventory instructions
For every file or folder, record:
- whether it exists
- what it does
- which phase it belongs to
- whether it is complete, partial, missing, or stale
- what it depends on
- what blocks Phase 6
