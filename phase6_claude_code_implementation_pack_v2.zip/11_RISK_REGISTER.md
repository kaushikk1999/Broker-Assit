# Risk Register

| Risk | Impact | Likelihood | Mitigation |
|---|---|---:|---|
| Wrong intent classification | Knowledge queries may bypass RAG or market queries may hit Qdrant | Medium | Verify intent taxonomy and add tests |
| Missing translation-before-retrieval | Hindi/Tamil retrieval quality degrades | High | Enforce translation step in pipeline |
| Reranker endpoint unavailable | Retrieval precision drops | Medium | Add timeout and fallback ranking policy |
| Citation lookup drift | Incorrect or stale citations | Medium | Resolve citations only from PostgreSQL |
| Rate limit gap | Abuse and cost runaway | High | Gate all paid calls behind auth/rate limit |
