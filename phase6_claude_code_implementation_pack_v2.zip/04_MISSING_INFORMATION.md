# Information Required Before Phase 6

## Mandatory inputs to confirm
- Exact intent categories and routing rules
- Sarvam API contract for detection and translation
- Hosted reranker endpoint contract
- Qdrant payload schema and filter fields
- RRF parameters and top-k settings
- Maximum context size and answer length policy
- Citation formatting rules
- Confidence threshold / fallback behavior
- Source precedence when documents conflict
- Tenant-specific domain allowlist policy
- Rate limits and quota thresholds
- Fallback behavior when translation or reranking fails

## Why this matters
Phase 6 depends on these inputs to ensure routing accuracy, retrieval quality, cost control,
and citation integrity.
