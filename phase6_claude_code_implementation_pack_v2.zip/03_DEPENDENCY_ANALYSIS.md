# Phase 6 Dependency Analysis

| Dependency | Why it is required | Status to confirm | Blocks Phase 6 |
|---|---|---:|---:|
| Auth and rate limiting | Prevent abuse and control model spend | Verify in code | Yes if incomplete |
| Language detection | Route multilingual input correctly | Verify Sarvam adapter or mock | Yes |
| Intent classification | Split market-data vs knowledge flows | Verify router | Yes |
| Query translation | Required before retrieval for EN/HI/TA recall | Verify translation service | Yes |
| Query expansion | Improves recall | Verify design choice | Usually yes |
| Embedding service | Produces dense query vectors | Verify embeddinggemma path | Yes |
| Qdrant collection validation | Ensures dense + sparse storage contract | Verify startup validation | Yes |
| Sparse vector support | Enables keyword search | Verify native sparse config | Yes |
| RRF fusion | Combines dense and sparse rankings | Verify implementation | Yes |
| Metadata filters | Filter candidates at retrieval time | Verify filters on both branches | Yes |
| Hosted reranker | Improves precision before generation | Open ADR in docs | Yes |
| PostgreSQL citation lookup | Resolves source metadata | Verify registry service | Yes |
| Redis cache | Market-data branch and rate limiting | Verify operational | Yes if market route is live |
| Ollama Cloud generation | Final response generation | Verify endpoint | Yes |
