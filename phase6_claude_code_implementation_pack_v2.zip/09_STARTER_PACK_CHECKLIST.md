# Starter Pack Checklist

## Before using Claude Code
- [ ] Read the roadmap-aligned requirements
- [ ] Read the architecture overview and pipeline docs
- [ ] Map the repo using the file inventory template
- [ ] Verify code reality against the Phase 6 pipeline
- [ ] Confirm dependency status for auth, translation, retrieval, reranking, and citations
- [ ] Confirm business decisions that affect retrieval behavior
- [ ] Confirm technical assets and credentials
- [ ] Complete the module audit checklist
- [ ] Pass the readiness gates
- [ ] Draft the implementation plan only after verification
