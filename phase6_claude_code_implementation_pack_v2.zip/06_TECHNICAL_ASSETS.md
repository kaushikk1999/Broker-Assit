# Technical Assets Required

## Services and credentials
- Ollama Cloud API key and base URL
- embeddinggemma model access
- Gemma generation model access
- Sarvam AI credentials
- Hosted reranker endpoint URL and auth
- Qdrant URL and API key
- PostgreSQL URL
- Redis URL
- Railway deployment config
- Widget origin allowlists and API keys

## Infrastructure assets
- Qdrant collection `brokerage_kb`
- PostgreSQL document registry schema
- Redis cache configuration
- Logging/monitoring setup
- Test fixtures for mock mode

## Why required
These assets connect the canonical pipeline to real infrastructure and keep the system secure
and observable.
