# Business Decisions Required

1. Retrieval strategy defaults: dense-first, sparse-first, or balanced hybrid.
2. RRF weighting and fusion behavior.
3. Maximum number of retrieved chunks.
4. Maximum number of reranked chunks sent to generation.
5. Citation display format in the UI.
6. Confidence threshold for answering vs abstaining.
7. Fallback policy when no evidence is found.
8. Language fallback behavior when detection is uncertain.
9. Response length policy.
10. Source authority precedence on conflicting data.
11. Tone and compliance disclaimer rules.
12. Tenant-specific overrides and branding.

These decisions affect user trust, latency, cost, and compliance.
