# Code Review Prompts for Claude Code

- Show me where auth and rate limiting are enforced before any model call.
- Show me the exact intent router logic and the routing fork.
- Show me where non-English queries are translated before retrieval.
- Show me the Qdrant query path for dense and sparse retrieval.
- Show me how metadata filters are applied during retrieval.
- Show me how RRF fusion is implemented.
- Show me how the reranker is called and what contract it uses.
- Show me how citations are resolved from PostgreSQL using document_id and chunk_id.
- Show me the mocks-first path and how it stays credential-free.
