# Open Questions for Owner

- Which reranker endpoint will be used in production?
- Which Sarvam endpoints are in scope for Phase 6?
- What is the fallback when translation fails?
- What is the maximum context size for generation?
- What citation format should the UI render?
