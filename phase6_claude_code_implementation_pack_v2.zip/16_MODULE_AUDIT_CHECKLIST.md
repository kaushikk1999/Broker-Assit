# Module-by-Module Audit Checklist

## Backend
- [ ] `app/main.py` boot sequence
- [ ] `app/config.py` env contract
- [ ] `app/core/security.py` widget auth
- [ ] `app/core/ratelimit.py` quotas and abuse control
- [ ] `app/services/intent_router.py` routing fork
- [ ] `app/services/rag_pipeline.py` retrieve-then-rerank flow
- [ ] `app/services/market_service.py` live market-data path
- [ ] `app/services/document_registry_service.py` citation lookup
- [ ] `app/adapters/qdrant_real.py` collection validation
- [ ] `app/adapters/ollama_cloud.py` remote model calls
- [ ] `app/db/models.py` registry and citation schema
- [ ] `app/api/routes_chat.py` chat endpoint behavior
- [ ] `app/api/routes_admin.py` admin controls
- [ ] `app/worker/embed_runner.py` non-web worker path

## Frontend
- [ ] `frontend/app/page.jsx` assistant entry
- [ ] `frontend/app/nalco/page.jsx` NALCO view
- [ ] `frontend/components/Assistant.jsx` chat flow
- [ ] `frontend/lib/api.js` backend client
- [ ] `frontend/lib/i18n.js` language support
