# Phase 6 Architecture Review

## Strengths
- Clear fork between market-data and knowledge requests
- Explicit citation source-of-truth in PostgreSQL
- Hosted model strategy keeps Railway free of model weights
- Qdrant hybrid retrieval is a good fit for the problem
- Mocks-first posture supports safe development

## Gaps to validate
- Intent router exists and is accurate
- Query translation occurs before retrieval
- Dense and sparse retrieval are both operational
- Metadata filters are applied during retrieval
- RRF fusion is implemented
- Reranker is hosted and contractually defined
- Citation resolution service is real and tested

## Risks
- Latency from translation + retrieval + reranking
- Failure of hosted services
- Schema drift in Qdrant or PostgreSQL
- Misclassification of market-data questions
