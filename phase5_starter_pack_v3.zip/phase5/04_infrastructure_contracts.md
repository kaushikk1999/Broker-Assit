# Infrastructure and Service Requirements

## Railway
- backend service env vars
- embedding worker or job runner
- startup readiness checks
- outbound HTTPS access

## Qdrant
- dense + native sparse vector support
- runtime-sized dense vector config
- collection validation at startup

## Ollama Cloud
- `embeddinggemma` model
- secure auth
- probe-based dimension detection

## PostgreSQL
- registry tables accessible
- FK lookup path available
