# Environment Variables Matrix

| Variable | Purpose | Required | Default |
|---|---|---:|---|
| BA_USE_MOCKS | keep dev mode credential-free | Yes | true |
| BA_DATABASE_URL | DB connection | Yes | sqlite:///./dev.db or prod PostgreSQL URL |
| BA_QDRANT_URL | Qdrant endpoint | Yes | unset |
| BA_QDRANT_API_KEY | Qdrant auth | If cloud-managed | unset |
| BA_QDRANT_COLLECTION_NAME | canonical collection | Yes | brokerage_kb |
| BA_QDRANT_DENSE_VECTOR_NAME | dense vector key | Yes | dense |
| BA_QDRANT_SPARSE_VECTOR_NAME | sparse vector key | Yes | sparse |
| BA_OLLAMA_CLOUD_URL | Ollama endpoint | Yes | unset |
| BA_OLLAMA_CLOUD_API_KEY | Ollama auth | Yes | unset |
| BA_EMBEDDING_MODEL | model name | Yes | embeddinggemma |
| BA_EMBEDDING_DIMENSION_OVERRIDE | optional validation override | Optional | unset |
| BA_EMBEDDING_BATCH_SIZE | batch size | Yes | 16 |
| BA_EMBEDDING_CONCURRENCY | concurrency | Yes | 2 |
| BA_EMBEDDING_RETRY_COUNT | retry count | Yes | 3 |
| BA_EMBEDDING_TIMEOUT_SECONDS | timeout | Yes | 30 |
| BA_QDRANT_CREATE_COLLECTION_ON_STARTUP | create missing collection | Yes | false |
| BA_QDRANT_VALIDATE_ON_STARTUP | validate collection at startup | Yes | true |
| BA_INGESTION_FAIL_FAST | fatal error policy | Yes | true |
| BA_METADATA_LANGUAGE_CODES | language enum list | Yes | en,hi,ta |
| BA_METADATA_FILING_TYPES | filing type list | Yes | Annual Report,Quarterly Results,Shareholding Pattern,Board Meeting,Corporate Action,Financial Results,Press Release,Presentation,FAQ |
| BA_CHUNK_SIZE | chunk length | If Phase 5 owns/validates chunking | 500 |
| BA_CHUNK_OVERLAP | chunk overlap | If Phase 5 owns/validates chunking | 100 |
| BA_LOG_LEVEL | log verbosity | Optional | INFO |
| BA_SENTRY_DSN | error tracking | Optional | unset |
