# Phase 5 Test Cases List

## Config tests
- missing env var fails validation
- defaults are loaded correctly
- override values are respected

## Ollama tests
- probe returns vector length
- 429 retries according to policy
- timeout is handled
- unreachable model fails startup

## Qdrant tests
- collection not found behavior
- create-on-startup policy respected
- dimension mismatch fails fast
- sparse vector config missing fails fast

## Metadata tests
- invalid language rejected
- invalid filing type rejected
- malformed date rejected
- company normalization applied consistently

## Pipeline tests
- chunk -> dense embedding -> sparse vector -> payload -> Qdrant flow succeeds
- duplicate input does not create duplicate embeddings
- reindex scenario deletes/replaces stale points

## Regression tests
- citations remain PostgreSQL-only
- no local model weights loaded
- mock-first mode still works without credentials
