# Ollama Cloud Contract

## Required information
- base URL
- authentication method
- `embeddinggemma` model identifier/version
- request schema
- response schema
- rate limits
- timeout policy
- retryable status codes

## Runtime behavior
- remote embedding generation only
- no local weights on Railway
- probe embedding length at startup for dimension validation
- fail startup on unreachable model or unstable contract
