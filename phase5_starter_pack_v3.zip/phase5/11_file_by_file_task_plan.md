# File-by-File Claude Code Task Plan

## 1. `app/config.py`
### Task
Add Phase 5 settings and validation defaults.
### Acceptance criteria
- all Phase 5 env vars are declared
- defaults are explicit
- no hardcoded vector dimension is introduced
- mock-first mode still works without vendor secrets

## 2. `app/adapters/base.py`
### Task
Confirm/extend adapter interface boundaries if needed for embedding provider support.
### Acceptance criteria
- embedding provider has a clean interface
- no model weights load in-process
- mock implementation remains supported

## 3. `app/adapters/ollama_cloud.py` or equivalent new adapter file
### Task
Implement remote embedding call surface and dimension probe support.
### Acceptance criteria
- can call embeddinggemma remotely
- probe returns vector length
- transient failures are handled according to policy

## 4. `app/adapters/qdrant_real.py`
### Task
Add collection inspection, create/validate logic, and upsert support for dual vectors.
### Acceptance criteria
- collection existence can be checked
- dense and sparse vector configs can be validated
- payload schema is enforced
- collection mismatch fails startup

## 5. `app/services/embedding_pipeline.py` (new or equivalent)
### Task
Implement the Phase 5 orchestration pipeline.
### Acceptance criteria
- reads registered chunks
- generates dense embeddings
- generates sparse vectors
- validates metadata
- writes to Qdrant with FK-only payloads
- fails fast on mismatch

## 6. `app/services/document_registry_service.py` (if needed)
### Task
Provide stable registry lookup helpers for citations and chunk metadata.
### Acceptance criteria
- lookup by document_id/chunk_id works
- no citation fields are stored in Qdrant

## 7. `app/entrypoint/main.py`
### Task
Wire startup readiness validation for embedding/Qdrant dependencies.
### Acceptance criteria
- service refuses to start on invalid config
- health/readiness reflects Phase 5 status

## 8. `tests/test_phase5_*.py`
### Task
Add tests for startup validation, dimension detection, payload validation, and Qdrant writes.
### Acceptance criteria
- all expected failure modes are covered
- mocks-first tests pass without live credentials
