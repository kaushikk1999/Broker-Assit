# Risks, Blockers, and Open Questions

## Blockers
- missing Ollama Cloud credentials or endpoint
- missing Qdrant endpoint or auth
- missing Phase 4 chunk contract
- missing metadata normalization rules
- missing sparse vector implementation detail

## Risks
- dimension mismatch causing startup failure
- payload schema drift causing retrieval errors
- stale embeddings after reindex
- silent retry loops and duplicate points

## Open questions
- create collection on startup or validate-only?
- exact point ID scheme?
- delete vs soft-delete for stale chunks?
- queue-and-retry or fail-fast when vendor is down?
