# Strict What Not To Touch

## Do not modify
- earlier phase deliverables
- unrelated frontend pages
- market-data branch logic
- translation/language services unless required for metadata support
- citation rendering logic except for registry lookup integration
- admin/security/rate-limit behavior unless the Phase 5 integration strictly requires it
- later-phase RAG retrieval logic beyond the storage contract boundary
- deployment topology for unrelated services

## Do not introduce
- local embedding weights
- local reranker weights
- hardcoded embedding dimensions
- citations in Qdrant payloads
- extra vector stores
- silent fallback to a different embedding model
- new collection naming schemes without approval
- schema changes that break registry integrity
