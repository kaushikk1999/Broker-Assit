# Phase 5 Starter Pack Checklist

## Inputs to confirm before coding
- [ ] Phase 4 chunk contract
- [ ] PostgreSQL registry schema
- [ ] Qdrant collection name and vector names
- [ ] Ollama Cloud endpoint and auth
- [ ] metadata enums and canonical values
- [ ] retry/timeout/backoff policy
- [ ] batch size and concurrency
- [ ] collection creation policy
- [ ] delete/reindex policy
- [ ] worker/runtime entrypoint

## Acceptance gates
- [ ] collection validation passes at startup
- [ ] probe returns stable embedding dimension
- [ ] dense + sparse vectors can be upserted
- [ ] payload stores only allowed keys
- [ ] citations remain PostgreSQL-only
- [ ] no local model weights are introduced
