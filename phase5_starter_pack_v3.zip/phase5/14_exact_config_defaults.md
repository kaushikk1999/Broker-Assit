# Exact Config Defaults

These are the defaults the project owner should approve for Phase 5 unless explicitly changed.

- BA_USE_MOCKS=true
- BA_QDRANT_COLLECTION_NAME=brokerage_kb
- BA_QDRANT_DENSE_VECTOR_NAME=dense
- BA_QDRANT_SPARSE_VECTOR_NAME=sparse
- BA_EMBEDDING_MODEL=embeddinggemma
- BA_EMBEDDING_BATCH_SIZE=16
- BA_EMBEDDING_CONCURRENCY=2
- BA_EMBEDDING_RETRY_COUNT=3
- BA_EMBEDDING_TIMEOUT_SECONDS=30
- BA_QDRANT_CREATE_COLLECTION_ON_STARTUP=false
- BA_QDRANT_VALIDATE_ON_STARTUP=true
- BA_INGESTION_FAIL_FAST=true
- BA_METADATA_LANGUAGE_CODES=en,hi,ta
- BA_METADATA_FILING_TYPES=Annual Report,Quarterly Results,Shareholding Pattern,Board Meeting,Corporate Action,Financial Results,Press Release,Presentation,FAQ
- BA_CHUNK_SIZE=500
- BA_CHUNK_OVERLAP=100
- BA_LOG_LEVEL=INFO

Notes:
- The Qdrant and Ollama URLs/API keys must be injected as secrets, not defaulted.
- If the owner wants collection auto-creation, toggle BA_QDRANT_CREATE_COLLECTION_ON_STARTUP to true after confirming operational policy.
