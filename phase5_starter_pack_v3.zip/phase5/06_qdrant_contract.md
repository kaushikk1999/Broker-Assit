# Qdrant Contract

## Canonical collection
- `brokerage_kb`

## Required vector layout
- dense vector: runtime-sized, cosine distance
- sparse vector: Qdrant native sparse vector

## Required behavior
- detect dense dimension dynamically from a probe embedding
- do not hardcode vector size
- create collection only if explicitly allowed and absent
- validate existing collection on startup
- fail fast on mismatch

## Payload contract
Only store:
- document_id
- chunk_id
- language
- company
- filing_type
- date

Do not store:
- source URL
- source name
- document version
- checksum
- citation text
