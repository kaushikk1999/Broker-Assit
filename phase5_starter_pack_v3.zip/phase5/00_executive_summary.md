# Phase 5 — Executive Summary

## Goal
Implement the embedding pipeline that converts registered chunked documents into:
- dense embeddings from Ollama Cloud using `embeddinggemma`
- sparse vectors using Qdrant native sparse vectors
- Qdrant points written into the dual-vector collection `brokerage_kb`

## Operational thesis
Phase 5 should be a **strict, validated boundary** between:
1. PostgreSQL registry/chunk records
2. Ollama Cloud embedding generation
3. Qdrant dual-vector persistence

The system must fail fast if:
- the embedding model is unreachable
- the returned vector dimension does not match the collection
- the collection schema is wrong
- the payload metadata is malformed
- required secrets/config are missing

## Non-negotiables
- no citation fields in Qdrant
- no local model weights on Railway
- no hardcoded dimensions
- no collection drift
- no silent fallback to incompatible storage
