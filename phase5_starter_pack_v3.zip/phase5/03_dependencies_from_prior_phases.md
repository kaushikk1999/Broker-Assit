# Dependencies from Prior Phases

## Phase 3
- Document Registry schema and persistence
- security/rate-limit/observability scaffolding
- config system
- Redis support

## Phase 4
- chunked cleaned document output
- metadata extraction and versioning completion
- deduplication and checksum completion

## Cross-phase
- Qdrant client capable of collection inspection and upsert
- downstream Phase 6 retrieval must understand the payload shape
