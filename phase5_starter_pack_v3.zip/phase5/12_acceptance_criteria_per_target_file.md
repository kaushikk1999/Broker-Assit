# Acceptance Criteria Per Target File

## Config files
- Phase 5 env vars present
- defaults are safe and explicit
- mock-first path remains unbroken

## Adapter files
- Ollama Cloud can be probed
- Qdrant collection can be validated
- retries/backoff honor policy

## Pipeline service files
- chunk input is consumed from the agreed contract
- dense + sparse vectors are produced
- metadata is validated
- Qdrant upserts are idempotent

## Startup/entrypoint files
- readiness check fails fast on invalid vendor state
- startup does not silently proceed with mismatched dimensions

## Tests
- unit tests for config, adapters, metadata, and validation
- integration-style tests for pipeline orchestration using mocks
- negative tests for dimension mismatch and missing collection
