# Required Decisions and Inputs Before Implementation

## Mandatory
1. Upstream chunk contract
2. Ollama Cloud API contract
3. Qdrant contract
4. Metadata normalization contract
5. Operational policy

## Clarifications needed
- exact PostgreSQL table names used for chunks
- whether Phase 5 reads from DB, queue, or files
- whether collection should be created on startup if absent
- exact dense and sparse vector names
- exact language/company/filing_type/date values
- fail-fast vs queue-and-retry on vendor failure
- retry count, timeout, batch size, concurrency
