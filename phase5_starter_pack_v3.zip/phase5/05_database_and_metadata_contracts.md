# Database and Metadata Contracts

## Source of truth
PostgreSQL remains the source of truth for citations.

## Required entities
- Document
- DocumentChunk
- DocumentVersion
- Audit history

## Qdrant payload
- document_id
- chunk_id
- language
- company
- filing_type
- date

## Validation rules
- FK integrity
- canonical language values
- canonical company spelling
- filing type taxonomy
- normalized date format

## Versioning rules
- checksum changes create new versions
- identical content must not duplicate embeddings
- reindexing must be deterministic and idempotent
