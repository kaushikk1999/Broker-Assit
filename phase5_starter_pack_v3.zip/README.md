# Phase 5 Implementation Brief + Requirements Bundle v3

This archive is the most implementation-direct starter pack for **Claude Code** to build **Phase 5 — Embedding Pipeline**.

## What this adds over v2
- File-by-file Claude Code task plan
- Acceptance criteria per target file
- Test cases list
- Exact config defaults
- Strict "what not to touch" section

## Intent
This bundle is meant to reduce ambiguity and push the implementation readiness closer to production-grade by making the task sequence explicit.

## Guardrails
- Use Ollama Cloud only
- Use embeddinggemma only
- No local embedding weights
- Keep citations in PostgreSQL only
- Use Qdrant native sparse vectors
- Do not hardcode embedding dimensions
- Do not touch unrelated phases unless required by the integration boundary
